import { Trash2, Edit2, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Exercise {
  id: number;
  name: string;
  calories_burned: number;
  duration_minutes?: number;
  date: string;
}

interface ExerciseCardProps {
  exercise: Exercise;
  onDelete: (id: number) => void;
  onEdit: (exercise: Exercise) => void;
}

export function ExerciseCard({
  exercise,
  onDelete,
  onEdit,
}: ExerciseCardProps) {
  return (
    <div className="group relative flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:bg-white/[0.04] hover:border-white/[0.08] transition-all duration-200">
      {/* Icon */}
      <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-orange-500/10 border border-orange-500/20">
        <Flame className="h-4 w-4 text-orange-400" />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <h3 className="font-medium text-foreground/90 truncate">
          {exercise.name}
        </h3>
        <div className="flex items-center gap-3 text-sm">
          <span className="font-medium text-orange-400">
            -{exercise.calories_burned} kcal
          </span>
          {exercise.duration_minutes && (
            <span className="text-muted-foreground/40 text-xs">
              {exercise.duration_minutes} min
            </span>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-muted-foreground/50 hover:text-foreground hover:bg-white/5"
          onClick={() => onEdit(exercise)}
        >
          <Edit2 className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-muted-foreground/50 hover:text-red-400 hover:bg-red-500/10"
          onClick={() => onDelete(exercise.id)}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}
