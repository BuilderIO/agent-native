import { cn } from "@/lib/utils";

interface DailyProgressProps {
  totalCalories: number;
  totalBurnedCalories: number;
  goalCalories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export function DailyProgress({
  totalCalories,
  totalBurnedCalories,
  goalCalories,
  protein,
  carbs,
  fat,
}: DailyProgressProps) {
  const netCalories = totalCalories - totalBurnedCalories;
  const percentage = Math.min(100, (netCalories / goalCalories) * 100);
  const remaining = Math.max(0, goalCalories - netCalories);
  const isOver = netCalories > goalCalories;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.01] border border-white/[0.06] p-6">
      {/* Decorative gradient orb */}
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br from-white/[0.03] to-transparent rounded-full blur-3xl" />

      <div className="relative flex flex-col gap-6">
        {/* Header row */}
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground/60 uppercase tracking-widest mb-4">
              Daily Summary
            </p>
            <div className="flex items-baseline gap-2">
              <span
                className={cn(
                  "text-6xl font-bold tracking-tighter",
                  isOver ? "text-red-400" : "text-foreground",
                )}
              >
                {netCalories}
              </span>
              <span className="text-lg text-muted-foreground/60">kcal</span>
            </div>
          </div>
          <div className="px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.06]">
            <span className="text-xs text-muted-foreground">
              Goal: {goalCalories}
            </span>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
            <span className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground/80">
                {totalCalories}
              </span>{" "}
              eaten
            </span>
          </div>
          {totalBurnedCalories > 0 && (
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-orange-400/60" />
              <span className="text-sm text-muted-foreground">
                <span className="font-medium text-orange-400">
                  {totalBurnedCalories}
                </span>{" "}
                burned
              </span>
            </div>
          )}
          <div className="flex items-center gap-2 ml-auto">
            <span className="text-sm text-muted-foreground">
              <span
                className={cn(
                  "font-medium",
                  isOver ? "text-red-400" : "text-foreground/80",
                )}
              >
                {remaining}
              </span>{" "}
              remaining
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-1 bg-white/[0.04] rounded-full overflow-hidden">
          <div
            className={cn(
              "h-full transition-all duration-500 ease-out rounded-full",
              isOver
                ? "bg-red-400"
                : "bg-gradient-to-r from-white/60 to-white/40",
            )}
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>

        {/* Macros */}
        {(protein > 0 || carbs > 0 || fat > 0) && (
          <div className="grid grid-cols-3 gap-3 pt-2">
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 mb-1">
                Protein
              </p>
              <p className="text-lg font-semibold text-foreground/90">
                {protein}g
              </p>
            </div>
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 mb-1">
                Carbs
              </p>
              <p className="text-lg font-semibold text-foreground/90">
                {carbs}g
              </p>
            </div>
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 mb-1">
                Fat
              </p>
              <p className="text-lg font-semibold text-foreground/90">{fat}g</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
