import { Link, useLocation, useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/hooks/use-toast";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export function AppHeader() {
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await signOut();
      navigate("/login");
    } catch (error) {
      toast({
        title: "Logout failed",
        variant: "destructive",
      });
    }
  };

  const isEntry = location.pathname === "/";
  const isAnalytics = location.pathname === "/analytics";

  return (
    <header className="sticky top-0 z-20 bg-background/60 backdrop-blur-xl border-b border-border/20 px-4 py-3">
      <div className="max-w-2xl lg:max-w-4xl mx-auto flex items-center justify-between">
        <Logo className="text-xl" />

        {/* Tab Navigation - Centered */}
        <nav className="absolute left-1/2 -translate-x-1/2 flex items-center gap-1">
          <Link to="/">
            <button
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                isEntry
                  ? "text-foreground bg-white/[0.1]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Entry
            </button>
          </Link>
          <Link to="/analytics">
            <button
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                isAnalytics
                  ? "text-foreground bg-white/[0.1]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Analytics
            </button>
          </Link>
        </nav>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Logout</TooltipContent>
        </Tooltip>
      </div>
    </header>
  );
}
