import { useQuery } from "@tanstack/react-query";
import { format, subDays } from "date-fns";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { AppHeader } from "@/components/AppHeader";
import { ChevronLeft } from "lucide-react";

interface DailyCalories {
  date: string;
  totalCalories: number;
  burnedCalories: number;
  netCalories: number;
  displayDate: string;
}

const GOAL_CALORIES = 2000;

export default function Analytics() {
  const { data: history, isLoading } = useQuery<DailyCalories[]>({
    queryKey: ["/api/meals/history"],
    queryFn: async () => {
      const endDate = new Date().toISOString().split("T")[0];
      const startDate = subDays(new Date(), 30).toISOString().split("T")[0];
      return await apiRequest(
        "GET",
        `/api/meals/history?startDate=${startDate}&endDate=${endDate}`,
      );
    },
  });

  const stats = history
    ? {
        average:
          Math.round(
            history.reduce((sum, day) => sum + day.netCalories, 0) /
              history.length,
          ) || 0,
        highest: Math.max(...history.map((day) => day.netCalories), 0),
        lowest: Math.min(...history.map((day) => day.netCalories), 0),
        total: history.length,
      }
    : { average: 0, highest: 0, lowest: 0, total: 0 };

  return (
    <div className="min-h-screen pb-20 relative z-10">
      <AppHeader />

      <main className="max-w-2xl lg:max-w-4xl mx-auto px-4 py-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <div className="p-4 rounded-xl bg-card/40 border border-border/30">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-2">
              Average
            </p>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-foreground">
                {stats.average}
              </span>
              <span className="text-xs text-muted-foreground">kcal</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-card/40 border border-border/30">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-2">
              Lowest
            </p>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-foreground">
                {stats.lowest}
              </span>
              <span className="text-xs text-muted-foreground">kcal</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-card/40 border border-border/30">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-2">
              Highest
            </p>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-foreground">
                {stats.highest}
              </span>
              <span className="text-xs text-muted-foreground">kcal</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-card/40 border border-border/30">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-2">
              Days Tracked
            </p>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-foreground">
                {stats.total}
              </span>
              <span className="text-xs text-muted-foreground">days</span>
            </div>
          </div>
        </div>

        {/* Charts with Tabs */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-md overflow-hidden">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-medium">
              Calorie Trend (Last 30 Days)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="net" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6 bg-secondary/40">
                <TabsTrigger value="net">Net</TabsTrigger>
                <TabsTrigger value="consumed">Consumed</TabsTrigger>
                <TabsTrigger value="burned">Burned</TabsTrigger>
              </TabsList>

              <TabsContent value="net" className="mt-0">
                {isLoading ? (
                  <Skeleton className="h-[300px] w-full rounded-xl" />
                ) : history && history.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart
                      data={history}
                      margin={{ top: 5, right: 5, bottom: 5, left: -20 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="hsl(var(--border))"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="displayDate"
                        stroke="hsl(var(--muted-foreground))"
                        style={{ fontSize: "10px" }}
                        tickLine={false}
                        axisLine={false}
                        dy={10}
                      />
                      <YAxis
                        stroke="hsl(var(--muted-foreground))"
                        style={{ fontSize: "10px" }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "12px",
                          boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
                        }}
                        itemStyle={{ fontSize: "12px" }}
                        labelStyle={{
                          fontSize: "12px",
                          color: "hsl(var(--muted-foreground))",
                          marginBottom: "4px",
                        }}
                        formatter={(value) => [`${value} kcal`, "Net Calories"]}
                      />
                      <ReferenceLine
                        y={GOAL_CALORIES}
                        stroke="hsl(var(--foreground))"
                        strokeDasharray="3 3"
                        strokeOpacity={0.3}
                      />
                      <Line
                        type="monotone"
                        dataKey="netCalories"
                        stroke="hsl(var(--foreground))"
                        strokeWidth={2}
                        dot={false}
                        activeDot={{
                          r: 4,
                          strokeWidth: 0,
                          fill: "hsl(var(--foreground))",
                        }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[300px] flex flex-col items-center justify-center text-muted-foreground rounded-xl border border-dashed border-border/50 bg-secondary/20">
                    <p className="text-sm">No data available yet</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="consumed" className="mt-0">
                {isLoading ? (
                  <Skeleton className="h-[300px] w-full rounded-xl" />
                ) : history && history.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart
                      data={history}
                      margin={{ top: 5, right: 5, bottom: 5, left: -20 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="hsl(var(--border))"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="displayDate"
                        stroke="hsl(var(--muted-foreground))"
                        style={{ fontSize: "10px" }}
                        tickLine={false}
                        axisLine={false}
                        dy={10}
                      />
                      <YAxis
                        stroke="hsl(var(--muted-foreground))"
                        style={{ fontSize: "10px" }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "12px",
                          boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
                        }}
                        itemStyle={{ fontSize: "12px" }}
                        labelStyle={{
                          fontSize: "12px",
                          color: "hsl(var(--muted-foreground))",
                          marginBottom: "4px",
                        }}
                        formatter={(value) => [`${value} kcal`, "Consumed"]}
                      />
                      <ReferenceLine
                        y={GOAL_CALORIES}
                        stroke="hsl(var(--foreground))"
                        strokeDasharray="3 3"
                        strokeOpacity={0.3}
                      />
                      <Line
                        type="monotone"
                        dataKey="totalCalories"
                        stroke="hsl(var(--foreground))"
                        strokeWidth={2}
                        dot={false}
                        activeDot={{
                          r: 4,
                          strokeWidth: 0,
                          fill: "hsl(var(--foreground))",
                        }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[300px] flex flex-col items-center justify-center text-muted-foreground rounded-xl border border-dashed border-border/50 bg-secondary/20">
                    <p className="text-sm">No data available yet</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="burned" className="mt-0">
                {isLoading ? (
                  <Skeleton className="h-[300px] w-full rounded-xl" />
                ) : history && history.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart
                      data={history}
                      margin={{ top: 5, right: 5, bottom: 5, left: -20 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="hsl(var(--border))"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="displayDate"
                        stroke="hsl(var(--muted-foreground))"
                        style={{ fontSize: "10px" }}
                        tickLine={false}
                        axisLine={false}
                        dy={10}
                      />
                      <YAxis
                        stroke="hsl(var(--muted-foreground))"
                        style={{ fontSize: "10px" }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "12px",
                          boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
                        }}
                        itemStyle={{ fontSize: "12px" }}
                        labelStyle={{
                          fontSize: "12px",
                          color: "hsl(var(--muted-foreground))",
                          marginBottom: "4px",
                        }}
                        formatter={(value) => [`${value} kcal`, "Burned"]}
                      />
                      <Line
                        type="monotone"
                        dataKey="burnedCalories"
                        stroke="#ea580c"
                        strokeWidth={2}
                        dot={false}
                        activeDot={{ r: 4, strokeWidth: 0, fill: "#ea580c" }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[300px] flex flex-col items-center justify-center text-muted-foreground rounded-xl border border-dashed border-border/50 bg-secondary/20">
                    <p className="text-sm">No data available yet</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
