import { z } from "zod";

export const mealSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, "Name is required"),
  calories: z.number().min(0),
  protein: z.number().min(0).optional(),
  carbs: z.number().min(0).optional(),
  fat: z.number().min(0).optional(),
  date: z.string(), // ISO string
  imageUrl: z.string().optional(),
  notes: z.string().optional(),
});

export type Meal = z.infer<typeof mealSchema>;

export interface DailyStats {
  date: string;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  meals: Meal[];
}

export interface AIAnalysisResponse {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  confidence: number;
}
