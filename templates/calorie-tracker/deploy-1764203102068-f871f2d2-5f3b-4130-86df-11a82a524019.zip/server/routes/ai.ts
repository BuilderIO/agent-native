import { Router } from "express";
import { AIAnalysisResponse } from "../../shared/api";
import Anthropic from "@anthropic-ai/sdk";

const router = Router();

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

router.post("/analyze-meal", async (req, res) => {
  try {
    const { description, imageBase64, imageMediaType } = req.body;

    if (!description && !imageBase64) {
      return res
        .status(400)
        .json({ error: "Either description or image is required" });
    }

    let analysisPrompt = `Analyze this meal and provide nutritional estimates in JSON format.

Return ONLY valid JSON (no markdown, no code blocks) with this exact structure:
{
  "name": "meal name",
  "calories": number,
  "protein": number,
  "carbs": number,
  "fat": number,
  "confidence": number between 0 and 1
}

`;

    if (imageBase64) {
      analysisPrompt += `Here is an image of a meal. Analyze it and estimate:
- Meal name/description
- Total calories
- Protein grams
- Carbs grams
- Fat grams
- Confidence level (0-1) in your estimate`;

      const message = await client.messages.create({
        model: "claude-3-5-haiku-20241022",
        max_tokens: 1024,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "image",
                source: {
                  type: "base64",
                  media_type: imageMediaType || "image/jpeg",
                  data: imageBase64,
                },
              },
              {
                type: "text",
                text: analysisPrompt,
              },
            ],
          },
        ],
      });

      const responseText =
        message.content[0].type === "text" ? message.content[0].text : "";
      const parsed = JSON.parse(responseText);
      res.json(parsed as AIAnalysisResponse);
    } else {
      analysisPrompt += `The user describes a meal: "${description}"

Estimate the nutritional content for this meal description.`;

      const message = await client.messages.create({
        model: "claude-3-5-haiku-20241022",
        max_tokens: 1024,
        messages: [
          {
            role: "user",
            content: analysisPrompt,
          },
        ],
      });

      const responseText =
        message.content[0].type === "text" ? message.content[0].text : "";
      const parsed = JSON.parse(responseText);
      res.json(parsed as AIAnalysisResponse);
    }
  } catch (error) {
    console.error("Error analyzing meal:", error);
    res.status(500).json({ error: "Failed to analyze meal" });
  }
});

export default router;
