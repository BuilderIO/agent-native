import "dotenv/config";
import express from "express";
import cors from "cors";
import mealRoutes from "./routes/meals";
import exerciseRoutes from "./routes/exercises";
import aiRoutes from "./routes/ai";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // API routes
  app.use("/api", mealRoutes);
  app.use("/api", exerciseRoutes);
  app.use("/api", aiRoutes);

  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  return app;
}
